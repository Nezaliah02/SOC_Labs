# Corrélation Nmap – Jour 1

- Nmap lancé depuis Ubuntu vers Windows (ports 22, 80, 135, 139, 445, 3389).
- Wireshark : SYN captés en direct.
- pfirewall.log : connexions ALLOW/DROP depuis IP Ubuntu.
- Sysmon : pas d’Event ID 3 → normal (trafic entrant uniquement).
